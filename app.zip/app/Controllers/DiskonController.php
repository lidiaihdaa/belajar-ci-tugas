<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\Exceptions\PageNotFoundException;

class DiskonController extends BaseController
{
    protected $db;
    protected $diskonTable;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->diskonTable = $this->db->table('diskon');
        helper(['form', 'url']);
    }

    public function index()
    {
        // Hanya admin yang bisa akses
        if (session()->get('role') !== 'admin') {
            throw PageNotFoundException::forPageNotFound();
        }

        // Ambil semua data diskon dari database
        $diskon = $this->diskonTable->orderBy('tanggal', 'ASC')->get()->getResult();

        // Cek apakah hari ini ada diskon
        $todayDiskon = $this->diskonTable->where('tanggal', date('Y-m-d'))->get()->getRow();

        return view('v_diskon', [
            'diskon' => $diskon,
            'todayDiskon' => $todayDiskon,
            'error' => session()->getFlashdata('error'),
        ]);
    }

    public function tambah()
    {
        $tanggal = $this->request->getPost('tanggal');
        $nominal = $this->request->getPost('nominal');

        // Cek apakah tanggal sudah pernah ditambahkan
        $cek = $this->diskonTable->where('tanggal', $tanggal)->countAllResults();

        if ($cek > 0) {
            session()->setFlashdata('error', 'Diskon untuk tanggal tersebut sudah ada!');
        } else {
            $this->diskonTable->insert([
                'tanggal' => $tanggal,
                'nominal' => $nominal
            ]);
        }

        return redirect()->to('/diskon');
    }

    public function edit()
    {
        $id = $this->request->getPost('id');
        $nominal = $this->request->getPost('nominal');

        $this->diskonTable->where('id', $id)->update(null, [
            'nominal' => $nominal
        ]);

        return redirect()->to('/diskon');
    }

    public function hapus($id)
    {
        $this->diskonTable->delete(['id' => $id]);
    }
}