<?php
session_start();
include 'koneksi.php';

// Cek apakah user adalah admin
if ($_SESSION['role'] != 'admin') {
    echo "Akses ditolak!";
    exit;
}

// Tambah data diskon
if (isset($_POST['tambah'])) {
    $tanggal = $_POST['tanggal'];
    $nominal = $_POST['nominal'];

    $cek = mysqli_query($conn, "SELECT * FROM diskon WHERE tanggal='$tanggal'");
    if (mysqli_num_rows($cek) > 0) {
        $error = "Diskon untuk tanggal tersebut sudah ada!";
    } else {
        mysqli_query($conn, "INSERT INTO diskon (tanggal, nominal) VALUES ('$tanggal', '$nominal')");
        header("Location: v_diskon.php");
    }
}

// Edit data diskon
if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $nominal = $_POST['nominal'];
    mysqli_query($conn, "UPDATE diskon SET nominal='$nominal' WHERE id='$id'");
    header("Location: v_diskon.php");
}

// Hapus data diskon
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM diskon WHERE id='$id'");
    header("Location: v_diskon.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Diskon</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <script src="assets/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container mt-5">
    <h3>Manajemen Diskon</h3>

    <?php
    // Banner info diskon hari ini
    $today = date('Y-m-d');
    $q = mysqli_query($conn, "SELECT * FROM diskon WHERE tanggal = '$today'");
    if (mysqli_num_rows($q) > 0) {
        $d = mysqli_fetch_assoc($q);
        echo "<div class='alert alert-success'>Hari ini ada diskon Rp " . number_format($d['nominal']) . " per item</div>";
    }
    ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalTambah">Tambah Data</button>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Tanggal</th>
                <th>Nominal (Rp)</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $no = 1;
        $data = mysqli_query($conn, "SELECT * FROM diskon ORDER BY tanggal ASC");
        while ($row = mysqli_fetch_assoc($data)) {
        ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $row['tanggal'] ?></td>
                <td><?= number_format($row['nominal']) ?></td>
                <td>
                    <!-- Edit button -->
                    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id'] ?>">Ubah</button>
                    <a href="v_diskon.php?hapus=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>

            <!-- Modal Edit -->
            <div class="modal fade" id="modalEdit<?= $row['id'] ?>" tabindex="-1">
                <div class="modal-dialog">
                    <form method="post" class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Diskon</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <div class="mb-3">
                                <label>Tanggal</label>
                                <input type="date" name="tanggal" value="<?= $row['tanggal'] ?>" class="form-control" readonly>
                            </div>
                            <div class="mb-3">
                                <label>Nominal (Rp)</label>
                                <input type="number" name="nominal" value="<?= $row['nominal'] ?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" name="edit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php } ?>
        </tbody>
    </table>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Diskon</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label>Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Nominal (Rp)</label>
                    <input type="number" name="nominal" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="tambah" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
